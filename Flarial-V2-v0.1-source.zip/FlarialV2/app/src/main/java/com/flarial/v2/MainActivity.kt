package com.flarial.v2

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var statusText: TextView
    private lateinit var versionText: TextView
    private var pendingType: ImportType = ImportType.ADDON

    private enum class ImportType(val title: String, val extensions: List<String>) {
        ADDON("Import Addon", listOf(".mcaddon", ".mcpack")),
        RESOURCE("Import Resource Pack", listOf(".mcpack", ".zip")),
        WORLD("Import World", listOf(".mcworld"))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun makeText(value: String, size: Float, color: Int, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
    }

    private fun makeButton(label: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF8655D9.toInt()))
            setOnClickListener { onClick() }
        }
    }

    private fun baseLayout(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(22), dp(24), dp(22), dp(24))
        setBackgroundColor(0xFF11101A.toInt())
    }

    private fun addGap(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun showHome() {
        val root = baseLayout()
        root.addView(makeText("FLARIAL V2", 30f, 0xFFB99AFF.toInt(), true))
        root.addView(makeText("BEDROCK CLIENT COMPANION", 11f, 0xFFA99BC5.toInt()))
        addGap(root, 74)

        val play = makeButton("PLAY", ::launchMinecraft)
        root.addView(play, LinearLayout.LayoutParams(-1, dp(58)))

        versionText = makeText(detectedMinecraftVersion(), 13f, 0xFFC7B7E8.toInt())
        root.addView(versionText)
        addGap(root, 62)

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val setting = makeButton("Setting", ::showSettings)
        val about = makeButton("Tentang", ::showAbout)
        bottom.addView(setting, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(6) })
        bottom.addView(about, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginStart = dp(6) })
        root.addView(bottom, LinearLayout.LayoutParams(-1, dp(58)))

        setContentView(root)
    }

    private fun showSettings() {
        val root = baseLayout()
        root.addView(makeText("SETTING", 26f, 0xFFB99AFF.toInt(), true))
        root.addView(makeText("IMPORT CONTENT", 11f, 0xFFA99BC5.toInt()))
        addGap(root, 22)
        root.addView(makeButton("Import Addons", { chooseFile(ImportType.ADDON) }),
            LinearLayout.LayoutParams(-1, dp(56)).apply { bottomMargin = dp(12) })
        root.addView(makeButton("Import Resource Packs", { chooseFile(ImportType.RESOURCE) }),
            LinearLayout.LayoutParams(-1, dp(56)).apply { bottomMargin = dp(12) })
        root.addView(makeButton("Import Worlds", { chooseFile(ImportType.WORLD) }),
            LinearLayout.LayoutParams(-1, dp(56)).apply { bottomMargin = dp(24) })
        statusText = makeText("Pilih file untuk mengirimnya ke Minecraft.", 12f, 0xFFC7B7E8.toInt())
        root.addView(statusText)
        addGap(root, 24)
        root.addView(makeButton("Kembali", ::showHome), LinearLayout.LayoutParams(-1, dp(52)))
        setContentView(root)
    }

    private fun showAbout() {
        val root = baseLayout()
        root.addView(makeText("TENTANG FLARIAL V2", 24f, 0xFFB99AFF.toInt(), true))
        addGap(root, 20)
        root.addView(makeText("Flarial V2 v0.1\\nMinecraft Bedrock companion untuk Android.\\n\\nDibuat dengan identitas visual original.", 15f, 0xFFC7B7E8.toInt()))
        addGap(root, 30)
        root.addView(makeButton("Kembali", ::showHome), LinearLayout.LayoutParams(-1, dp(52)))
        setContentView(root)
    }

    private fun detectedMinecraftVersion(): String {
        return try {
            val info = if (Build.VERSION.SDK_INT >= 33) {
                packageManager.getPackageInfo("com.mojang.minecraftpe", PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                packageManager.getPackageInfo("com.mojang.minecraftpe", 0)
            }
            "Minecraft Version: ${info.versionName ?: "Unknown"}"
        } catch (_: Exception) {
            "Minecraft Version: Not detected"
        }
    }

    private fun launchMinecraft() {
        val launch = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
        if (launch != null) {
            startActivity(launch)
        } else {
            Toast.makeText(this, "Minecraft resmi tidak terdeteksi. Kamu bisa membuka Minecraft yang kompatibel secara manual.", Toast.LENGTH_LONG).show()
        }
    }

    private fun chooseFile(type: ImportType) {
        pendingType = type
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            this.type = "*/*"
        }
        try {
            startActivityForResult(intent, 101)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "File picker tidak tersedia di perangkat ini.", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated by Android, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 101 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        val name = getDisplayName(uri) ?: "file"
        val allowed = pendingType.extensions.any { name.lowercase().endsWith(it) }
        if (!allowed) {
            Toast.makeText(this, "Format file tidak sesuai untuk ${pendingType.title}.", Toast.LENGTH_LONG).show()
            return
        }
        sendToMinecraft(uri, name)
    }

    private fun getDisplayName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) return cursor.getString(index)
            }
        }
        return uri.lastPathSegment
    }

    private fun sendToMinecraft(uri: Uri, fileName: String) {
        val mime = when {
            fileName.endsWith(".mcworld", true) -> "application/x-mcworld"
            fileName.endsWith(".mcpack", true) -> "application/x-minecraft-pack"
            fileName.endsWith(".mcaddon", true) -> "application/x-minecraft-addon"
            fileName.endsWith(".zip", true) -> "application/zip"
            else -> contentResolver.getType(uri) ?: "*/*"
        }
        val viewIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(Intent.createChooser(viewIntent, "Buka dengan Minecraft"))
            Toast.makeText(this, "File siap dibuka: $fileName", Toast.LENGTH_SHORT).show()
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "Tidak ada aplikasi yang menerima file ini. Coba buka file dari File Manager dan pilih Minecraft.", Toast.LENGTH_LONG).show()
        }
    }
}
